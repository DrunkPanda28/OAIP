july_city = input()
august_city = input()

if july_city == "Тула" and august_city == "Пенза" or july_city == "Пенза" and august_city == "Тула":
    print("НЕТ")
else:
    print("ДА")