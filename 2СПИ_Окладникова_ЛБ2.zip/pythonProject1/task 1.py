slow = input()

#Проверяем условие
if slow == "python":
    print("Да")
else:
    print("Нет")
