# Запрос числа покупателей за позавчера и вчера
buyers_day_before_yesterday = int(input("Введите число покупателей позавчера: "))
buyers_yesterday = int(input("Введите число покупателей вчера: "))

# Вычисление разницы
difference = buyers_yesterday - buyers_day_before_yesterday

# Прогноз на сегодня
if difference > 0:
    # Если количество покупателей увеличивается
    buyers_today = buyers_yesterday + difference
else:
    # Если количество покупателей уменьшается
    buyers_today = buyers_yesterday - abs(difference)


print("Сегодня магазин посетит:", buyers_today)

