a = input()
b = input()

if a == "Да" and b == "Нет":
    print("Верно")
elif a == "Да" or b == "Нет":
    print("Верно")
else:
    print("Неверно")