width = input("Введите трехзначное число: ")

# Получаем первую, среднюю и третью цифры
first_digit = int(width[0])
middle_digit = int(width[1])
third_digit = int(width[2])

# Cумма первой и третьей цифры
sum_first_third = first_digit + third_digit

# Проверяем условия
if sum_first_third % 8 != 0 and middle_digit == 3:
    print("Подходит")
else:
    print(sum_first_third, middle_digit)
