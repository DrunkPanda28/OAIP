numbers = int(input())
if numbers % 2 == 0:
    print(numbers, "Число четное")
else:
    print(numbers,"Число не четное")