a = input()
b = input()
c = input()

if a == 'Раз' and b == 'Два' and c == 'Три':
    print("Гори")
elif a == '1' and b == "2" and c == "3":
    print("Гори")
else:
    print("Не гори")