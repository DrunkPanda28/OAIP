# Ввод цен товаров
prices = []
for i in range(3):
    price = float(input(f"Введите цену товара {i+1}: \n"))
    prices.append(price)

# Вычисляем сумму
total = sum(prices)

# Проверяем условия на акцию
if prices == sorted(prices):
    print("Акция! \nОбщая сумма:", total / 2)
elif prices == sorted(prices, reverse=True):
    print("Акция! \nОбщая сумма:", total / 3)
else:
    print("К оплате:", total)
