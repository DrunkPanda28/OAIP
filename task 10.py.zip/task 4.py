numbers = input("Введите числа через пробел: \n")
number = list(map(int, numbers.split()))
if len(str(numbers)) == 0:
    print("здесь нет чисел")
else:
    number_min = numbers[0]
    i = 1
# noinspection PyTypeChecker,PyUnboundLocalVariable
while i < len(numbers):
    # noinspection PyUnboundLocalVariable
    if numbers[i] < number_min:
        number_min = numbers[i]
    i += 1
print(number_min)
