result = []

while True:
    text = input("Введите предложение или стоп для завершения программы: ")

    if text == 'Стоп':
        break

    result.append(text)
    #Объединяем все слова в одну строку
    words = ''.join(result)

    #Разделяем на предложения
    settens = words.split('!')

    for setten in settens:
        setten = setten.strip()

        if setten:
            print(setten + "!")
