a = int(input())

while a % 3 == 0:
    print("Ваше число не счастливое")
    break

if a % 7 == 0:
    print("Ваше число может являтся опасным")

if a % 7 == 0 and a % 3 == 0:
    print("КАРАУЛ!")