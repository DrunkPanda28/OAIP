short_word = None
while True:
    words = input("Введите слово или стоп для завершения")

    if words.lower() == 'стоп':
        break
    if short_word is None or len(words) <= len(short_word):
        short_word = words

    if short_word is not None:
        print("Самое короткое слово", short_word)
    else:
        print('Пустая строка')