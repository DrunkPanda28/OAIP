a = input()
while a <= "36.6":
    if a <= "0":
        i = len(str(a)) - a.count(" ")
        print(i)
        break
