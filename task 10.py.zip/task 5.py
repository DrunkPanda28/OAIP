a = list(range(1, 10001))
print(a)

while a != 0:
    cum = sum(a)
    print(cum)
    break
