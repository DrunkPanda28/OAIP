a = input()
while a != '':
    print(a)
    break
line = len(str(a))
print(line)
