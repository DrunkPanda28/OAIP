a = input('Введите три числа: ')

while '-1000' >= a <= "1000":
    maxim = int(max(a))
    print(a)
