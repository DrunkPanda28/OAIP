porol = input()
consonants = ['б', 'в', 'г', 'д', 'ж', 'з', 'й', 'к', 'л', 'м', 'н', 'п', 'р', 'с', 'т', 'ф', 'х', 'ц', 'ч', 'ш', 'щ']
vowels = ['а', 'о', 'у', 'э', 'ы', 'я', 'ё', 'ю', 'е', 'и']
for porol in consonants:
    porol *= 0
    print(porol)
for porol in vowels:
    porol = len(porol)
    porol.count('')
    print(porol)