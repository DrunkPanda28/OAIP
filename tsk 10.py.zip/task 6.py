a = input(str())
vowels = ('аоуэыяёюеи')
count = 0
words = a.strip().split()
for word in words: #проходим по каждому слову в списке
    for num in word: #Проходим по каждой букве
        if num in vowels: #Проверяем является ли буква безударной
            count += 1
print(count)
