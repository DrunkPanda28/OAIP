phone_number = input("Введите номер телефона: ")

# Проверяем номер на наличие недопустимых символов
if not all(char.isdigit() or char == '+' for char in phone_number):
    print("Неправильный номер телефона!")
else:
    print("Номер телефона принят.")