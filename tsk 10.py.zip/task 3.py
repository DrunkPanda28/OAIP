for i in range(int(input('Введите с какой даты начать поиск: ')), 32,
               int(input('Введите шаг: '))):
    print(i, end=' ')

