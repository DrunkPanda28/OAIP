# Определяем функции для проверки гласных и согласных букв
vowels = 'аеёиеоуюяАЕЁИЕОУЮЯ'

# Считываем пароль у пользователя
password = input("Введите пароль: ")

# Зашифровываем пароль
encrypted_password = ''.join('0' if char in vowels else '1' for char in password if char.isalpha())
print(encrypted_password)